package com.carbooking.util;

public class ExceptionUtil {
String message="invalid credentials";
}
